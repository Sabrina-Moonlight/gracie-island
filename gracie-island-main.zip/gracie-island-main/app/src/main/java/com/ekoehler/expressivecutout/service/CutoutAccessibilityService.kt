package com.ekoehler.expressivecutout.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.Configuration
import android.view.accessibility.AccessibilityEvent
import com.ekoehler.expressivecutout.core.ForegroundAppBus
import com.ekoehler.expressivecutout.events.MediaPlaybackMonitor
import com.ekoehler.expressivecutout.events.SystemEventMonitor
import com.ekoehler.expressivecutout.overlay.IslandOverlayController
import com.ekoehler.expressivecutout.system.AppLocale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The always-on host of the island. Its main purpose is to provide a context that can add
 * a TYPE_ACCESSIBILITY_OVERLAY window (no SYSTEM_ALERT_WINDOW required) and to keep the
 * overlay controller and system-event monitor alive for the lifetime of the binding.
 *
 * It also tracks which app is in the foreground (package name only); it reads no screen content.
 */
class CutoutAccessibilityService : AccessibilityService() {

    /** Localises the strings the island itself draws. See [AppLocale]. */
    override fun attachBaseContext(base: Context) = super.attachBaseContext(AppLocale.wrap(base))

    private var overlay: IslandOverlayController? = null
    private var systemEvents: SystemEventMonitor? = null
    private var mediaPlayback: MediaPlaybackMonitor? = null

    /**
     * Starts the overlay and the two event monitors, and publishes the service so the rest of the
     * app can see that the island is live. Mirrored by [teardown].
     */
    override fun onServiceConnected() {
        super.onServiceConnected()
        overlay = IslandOverlayController(this).also { it.start() }
        systemEvents = SystemEventMonitor(this).also { it.start() }
        mediaPlayback = MediaPlaybackMonitor(this).also { it.start() }
        instance = this
        _bound.value = true
    }

    /** Notes which app is in front. Nothing here reads content from any other app. */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        val pkg = ev.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return

        if (ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            ForegroundAppBus.update(pkg)
        }
    }

    /**
     * Forward device rotations to the overlay so it can rebuild its top-of-screen window for the new
     * geometry — otherwise the touchable-region carve-out that lets the notification shade through
     * beside the pill goes stale in landscape and the band swallows the shade pull.
     */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        overlay?.onOrientationChanged(newConfig.orientation)
    }

    /** Required by the framework. The island has no interruptible work of its own. */
    override fun onInterrupt() = Unit

    /**
     * Tears everything down on unbind, which is when the user turns the service off in settings.
     */
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    /**
     * Tears everything down on destroy, since a service can be killed without ever being unbound.
     */
    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    /**
     * Stops the monitors and the overlay and clears the published state. Written to be safe to call
     * twice, because unbind and destroy both reach it.
     */
    private fun teardown() {
        _bound.value = false
        instance = null
        mediaPlayback?.stop()
        mediaPlayback = null
        systemEvents?.stop()
        systemEvents = null
        overlay?.stop()
        overlay = null
    }

    companion object {
        /**
         * The live service instance while bound, used by [performGlobal] to fire system-wide actions
         * for the expanded "center" shortcuts. Held statically (the service has no android:process, so
         * it's this same process) and cleared in [teardown] so it never outlives the binding.
         */
        private var instance: CutoutAccessibilityService? = null

        /**
         * Perform a system-wide [AccessibilityService] global action (e.g. lock screen, screenshot,
         * quick settings) if the service is bound. Best-effort: returns false when nothing is bound
         * or the action is rejected, so callers can fall back or ignore it.
         */
        fun performGlobal(action: Int): Boolean =
            runCatching { instance?.performGlobalAction(action) }.getOrNull() ?: false

        private val _bound = MutableStateFlow(false)

        /**
         * True only while Android actually has this service bound — i.e. while the island is
         * really running. Deliberately separate from
         * [com.ekoehler.expressivecutout.permissions.Permissions.isAccessibilityGranted], which
         * reads the user's *consent* out of Settings.Secure: that stays "enabled" across a
         * reinstall or an app update while the binding is dead, so the app would otherwise report
         * itself healthy while nothing at all is listening. Lives in the companion object rather
         * than on the instance so the settings UI (same process — no android:process on the
         * service) can observe it without a binder of its own.
         */
        val bound: StateFlow<Boolean> = _bound.asStateFlow()
    }
}
