package com.ekoehler.expressivecutout.overlay

import android.app.PendingIntent
import android.app.RemoteInput
import androidx.annotation.RawRes
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import com.ekoehler.expressivecutout.data.CutoutColor
import com.ekoehler.expressivecutout.data.DynamicRole
import com.ekoehler.expressivecutout.data.MusicButtonStyle
import com.ekoehler.expressivecutout.data.MusicRightButtonAction
import com.ekoehler.expressivecutout.service.ProgressData
import com.ekoehler.expressivecutout.ui.components.ROBOTO_FLEX_DEFAULT_WIDTH

/**
 * A fully resolved, ready-to-render icon. Reducing every possible source (a Material
 * vector default, a user-picked image, or another app's launcher icon) to just two
 * cases keeps the [DynamicIsland] composable trivial and free of Android plumbing.
 */
@Immutable
sealed interface IslandIcon {
    /** A Material vector, drawn in the accent colour and always sharp at any size. */
    data class Vector(val image: ImageVector) : IslandIcon

    /**
     * A bitmap icon. Normally full-colour art that fills the badge (a launcher icon, a
     * notification's large icon). When [tint] is true it is instead a monochrome glyph — a
     * notification's small icon — so it is drawn glyph-sized and recoloured with the badge's ink,
     * like an [IslandIcon.Vector], rather than filling the disc with its own (often white) pixels.
     */
    data class Raster(val bitmap: ImageBitmap, val tint: Boolean = false) : IslandIcon

    /**
     * A Lottie animation from `res/raw`, played when the collapsed pill appears. Used for events that
     * read better as a motion beat than a static glyph (e.g. a padlock springing open for
     * [com.ekoehler.expressivecutout.core.SystemEventType.DEVICE_UNLOCKED]). [iterations] is how many
     * times to play ([com.airbnb.lottie.compose.LottieConstants.IterateForever] to loop). When
     * [clipStartFrame] / [clipEndFrame] are both set, only that frame range plays; otherwise the whole
     * composition does. [scale] multiplies the icon size (for artwork that sits small within its own
     * canvas — values > 1 render past the badge and are clipped to its circle), and [tint] recolours
     * every layer with the badge's glyph colour when true (so it follows the theme/accent like the
     * static icons), or leaves the animation's own colours when false.
     */
    data class Lottie(
        @param:RawRes val resId: Int,
        val iterations: Int = 1,
        val clipStartFrame: Int? = null,
        val clipEndFrame: Int? = null,
        val scale: Float = 1f,
        val tint: Boolean = false,
        val speed: Float = 1f,
    ) : IslandIcon
}

/**
 * Everything the island needs to show a single moment on screen. [label] is the primary
 * line (shown when expanded); [detail] is an optional secondary line (e.g. a notification
 * title). The collapsed island shows only the icon.
 */
@Immutable
data class IslandEvent(
    val id: Long,
    val icon: IslandIcon,
    val label: String,
    val detail: String? = null,
    val appName: String? = null,
    val postTimeMs: Long? = null,
    val accent: Color,
    /**
     * When true the icon badge ignores [accent] and is drawn with a Material You role colour and
     * its matching "on" ink instead — the "Dynamic color for all events" option. System events only.
     */
    val useThemeColor: Boolean = false,
    /** Which Material You role tints the badge when [useThemeColor] is on. */
    val themeColorRole: DynamicRole = DynamicRole.PRIMARY,
    /** Opacity (0..1) of the role-coloured badge background when [useThemeColor] is on. */
    val themeColorOpacity: Float = 1f,
    /**
     * A user-chosen per-event colour that replaces the event's own [accent] on the badge (a faint
     * tinted disc behind a full-colour glyph, like the default look). Wins over [useThemeColor], so
     * recolouring one event overrides the global dynamic-colour role for it. Null keeps the default.
     */
    val colorOverride: CutoutColor? = null,
    /**
     * Overrides the icon container (the disc behind the glyph) with a user-chosen colour, filled at
     * full opacity with contrasting ink. Set by the dynamic tiles from their settings; null keeps the
     * default look (a faint [accent]-tinted disc behind an [accent] glyph, or the [useThemeColor] role).
     */
    val iconContainerColor: CutoutColor? = null,
    val initiallyExpanded: Boolean = false,
    /**
     * The event never auto-hides: it stays in whichever slot it holds until the user dismisses it.
     * Set by the "Pin notifications" setting or the pin button on the expanded card.
     */
    val pinned: Boolean = false,
    /**
     * The user set "Normal only" for the posting app on the Apps screen: this pill has no expanded
     * state, so a tap opens the app via [contentIntent] instead of toggling it open. Same treatment
     * the phone tile gets by its nature, but chosen per app rather than implied by the tile.
     */
    val normalOnly: Boolean = false,
    /**
     * The tap action to run when the expanded island is tapped (a notification's content
     * intent). Null for events that have nothing to open (system events).
     */
    val contentIntent: PendingIntent? = null,
    /**
     * The originating notification's key, when this event mirrors one. Lets a swipe-to-dismiss
     * clear the real notification from the system, not just hide the pill. Null for everything else.
     */
    val notificationKey: String? = null,
    /** Optional action buttons shown as chips in the expanded island. */
    val actions: List<IslandAction> = emptyList(),
    /**
     * When non-null this is the music tile: the island shows album art on the collapsed pill and
     * playback controls when expanded (each gated by [MediaTileOptions]), reading live state from
     * [com.ekoehler.expressivecutout.core.NowPlayingBus]. Null for every other event.
     */
    val media: MediaTileOptions? = null,
    /**
     * When non-null this is the phone tile: the island shows the caller's photo on the collapsed
     * pill and the caller / duration / call actions when expanded (each gated by [CallTileOptions]),
     * reading live state from [com.ekoehler.expressivecutout.core.OnCallBus]. Null otherwise.
     */
    val call: CallTileOptions? = null,
    /**
     * When non-null this is the timer tile: the island shows a timer icon and the remaining time on
     * the collapsed pill, and the same plus its action buttons (Reset / Add 1 min) when expanded
     * (each gated by [TimerTileOptions]), reading the live countdown from
     * [com.ekoehler.expressivecutout.core.RunningTimerBus]. Null for every other event.
     */
    val timer: TimerTileOptions? = null,
    /**
     * Contains the progress of this notification if it is a progress one.
     * Is null otherwise
     */
    val progressData: ProgressData? = null,
    /** The package name of the app that posted this event, if any. */
    val packageName: String? = null,
    /** The primary branding color extracted from the posting app's default launcher icon, if any. */
    val appColor: Color? = null,
    /** Ring the notification badge with the same thin ring the album cover wears. */
    val badgeRing: Boolean = false,
    /**
     * Status indicator dot color (e.g. green for success/connected, red for danger/disconnected,
     * yellow for warning, blue for neutral/lock). When non-null, a pulsing/radiating dot is rendered
     * on the collapsed pill between the badge and the camera, and beside the badge on the expanded card.
     */
    val statusDotColor: Color? = null,
    /**
     * Trailing status text (e.g. battery percentage "85%") shown on the trailing edge of the collapsed
     * island instead of a status dot.
     */
    val trailingText: String? = null,
    /** Color for [trailingText]. Null falls back to theme content color. */
    val trailingTextColor: Color? = null,
    /** Additional multi-line detail strings rendered in the expanded island below [detail]. */
    val secondaryLines: List<String> = emptyList(),
    /** System Settings activity action to launch when the expanded island is tapped. */
    val actionIntentAction: String? = null,
    /** Optional URI data to attach to [actionIntentAction]. */
    val actionIntentUri: String? = null,
)

/** Which parts of the timer tile to render (and how its buttons look), per the tile's settings. */
data class TimerTileOptions(
    val showActions: Boolean,
    /** Fill of the Reset button. */
    val resetColor: CutoutColor,
    /** Fill of the "Add 1 min" button. */
    val addButtonColor: CutoutColor,
)

/** Which parts of the phone tile to render (and how the call buttons look), per its settings. */
data class CallTileOptions(
    val showPhoto: Boolean,
    val showDuration: Boolean,
    val showActions: Boolean,
    /** Label the wide call buttons (Take / Hang up) beside their icon instead of showing the icon alone. */
    val showButtonLabels: Boolean,
    /** Use the taller two-row layout for an incoming (ringing) call instead of the compact single row. */
    val incomingExpandedLayout: Boolean,
    /**
     * Draw the tiny cutout — the same small pill the music tile's "Mini player" uses, carrying only
     * a call glyph — in place of a connected call's normal cutout. A tap still opens the expanded
     * call controls. Ignored while the call is ringing: that layout carries the answer button.
     */
    val miniCall: Boolean = false,
    /** Fill of the hang-up / end-call button. */
    val hangUpColor: CutoutColor,
    /** Fill shared by every other call button. */
    val otherButtonColor: CutoutColor,
    /** Fill of the Take (answer) button on a ringing call. */
    val incomingAnswerColor: CutoutColor,
    /** Fill of the Hang up (decline) button on a ringing call. */
    val incomingHangUpColor: CutoutColor,
    /** Fill of the hang-up button on the expanded call card. */
    val expandedHangUpColor: CutoutColor,
)

/** Which parts of the music tile to render (and how the controls look), per the tile's settings. */
data class MediaTileOptions(
    val showAlbumArt: Boolean,
    /** Draw the album cover behind the expanded music player. */
    val showAlbumBackground: Boolean = false,
    /** How far that album background darkens towards black: 0 untouched, 1 black. */
    val albumBackgroundDim: Float,
    /** Blur radius of that album background in dp; null leaves it sharp. */
    val albumBackgroundBlurRadius: Int? = null,
    /** Spin the album art while playback is live, freezing it when paused. */
    val rotateAlbumArt: Boolean,
    /** Crop the cover to a full circle instead of a rounded square; implied by [rotateAlbumArt]. */
    val circleCover: Boolean = false,
    /** Ring the album art, set apart from it by a small gap. */
    val albumArtStroke: Boolean = false,
    /** Colour of that ring; null falls back to the tile's accent. */
    val albumArtStrokeColor: CutoutColor? = null,
    val showControls: Boolean,
    /** Show the playback progress bar under the controls. */
    val showProgress: Boolean = false,
    /** Look of the previous / next (skip) buttons. */
    val skipStyle: MusicButtonStyle = MusicButtonStyle.DEFAULT,
    /** Let the previous button take the controls row's leftover width. */
    val previousExpand: Boolean = false,
    /** Label the expanded previous button "Previous" instead of drawing its icon. */
    val previousText: Boolean = false,
    /** Roboto Flex `wdth` axis of that label. */
    val previousTextWidth: Float = ROBOTO_FLEX_DEFAULT_WIDTH,
    /** Let the next button take the controls row's leftover width. */
    val nextExpand: Boolean = false,
    /** Label the expanded next button "Next" instead of drawing its icon. */
    val nextText: Boolean = false,
    /** Roboto Flex `wdth` axis of that label. */
    val nextTextWidth: Float = ROBOTO_FLEX_DEFAULT_WIDTH,
    /** Look of the central play / pause button. */
    val playPauseStyle: MusicButtonStyle = MusicButtonStyle.DEFAULT,
    /** Let the play/pause button take the controls row's leftover width. */
    val playPauseExpand: Boolean = false,
    /** Label the expanded play/pause button "Play" / "Pause" instead of drawing its icon. */
    val playPauseText: Boolean = false,
    /** Roboto Flex `wdth` axis of that label. */
    val playPauseTextWidth: Float = ROBOTO_FLEX_DEFAULT_WIDTH,
    /**
     * Draw the tiny cutout — a small pill holding only the note glyph and the cover — in place of
     * the normal cutout while music plays. The expanded cutout is unchanged, and a tap still opens it.
     */
    val miniPlayer: Boolean = false,
    /**
     * Draw one transport button on the trailing edge of the normal cutout. Ignored while
     * [miniPlayer] is on: the tiny pill has no room for it.
     */
    val rightButton: Boolean = false,
    /** The action that button fires, and the icon it draws. */
    val rightButtonAction: MusicRightButtonAction = MusicRightButtonAction.PLAY_PAUSE,
)

/**
 * A single tappable action shown in the expanded island. A plain action fires [intent] on tap;
 * when [reply] is non-null the chip opens an inline text field and the typed text is sent through
 * [intent] instead.
 */
@Immutable
data class IslandAction(
    val label: String,
    val intent: PendingIntent? = null,
    val reply: IslandReply? = null,
    /** True for a destructive call action (hang up / end call / decline), so the phone tile can tint it apart. */
    val destructive: Boolean = false,
    /** True for an incoming call's answer / accept action, so the phone tile can render it as the take-call button. */
    val answer: Boolean = false,
)

/** Everything needed to send an inline reply through a notification action's intent. */
@Immutable
data class IslandReply(
    val resultKey: String,
    val remoteInputs: List<RemoteInput>,
    val hint: String?,
)

/**
 * Whether this event draws the tiny cutout in place of its own normal one: the music tile's "Mini
 * player", or the phone tile's "Mini call" on a call that has already connected ([callOngoing]) —
 * a ringing one keeps its layout so the answer button stays reachable. Shared by the overlay's
 * rendering and its window sizing so the two always agree on the pill's geometry.
 */
fun IslandEvent.usesTinyCutout(callOngoing: Boolean): Boolean =
    media?.miniPlayer == true || (call?.miniCall == true && callOngoing)

/**
 * Whether this event writes anything on the collapsed pill's trailing edge: the timer's remaining
 * time, a progress ring, the music tile's transport button, a trailing text such as the battery
 * percentage. The permission dots share that edge, so this is what
 * decides whether the pill has to grow to the right to hold both.
 *
 * Shared by the overlay's rendering and its window sizing, exactly as [usesTinyCutout] is, so the
 * two can't drift apart and leave the dots drawn outside the window that has to contain them.
 */
fun IslandEvent.hasCollapsedTrailingContent(): Boolean =
    timer != null || (progressData != null && !progressData.isComplete) ||
        (media?.rightButton == true && !media.miniPlayer) ||
        trailingText != null
