package com.ekoehler.expressivecutout.ui

import android.widget.Toast
import androidx.activity.BackEventCompat
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ekoehler.expressivecutout.R
import com.ekoehler.expressivecutout.data.JsonSettings
import com.ekoehler.expressivecutout.core.DynamicTile
import com.ekoehler.expressivecutout.core.SystemEventType
import com.ekoehler.expressivecutout.ui.components.BackNavBar
import com.ekoehler.expressivecutout.ui.components.ExpressiveNavBar
import com.ekoehler.expressivecutout.ui.components.NavBarItem
import com.ekoehler.expressivecutout.ui.screen.PermissionsTab
import com.ekoehler.expressivecutout.ui.screen.ProfileRoute
import com.ekoehler.expressivecutout.ui.screen.ProfileTab
import com.ekoehler.expressivecutout.ui.screen.SettingsRoute
import com.ekoehler.expressivecutout.ui.screen.SettingsTab
import com.ekoehler.expressivecutout.ui.screen.parent
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

/**
 * The three top-level tabs, in the order the nav bar shows them, each carrying its own label and
 * icon.
 */
private enum class HomeTab(
    @param:StringRes val labelRes: Int,
    val icon: ImageVector,
) {
    Settings(R.string.nav_settings, Icons.Rounded.Tune),
    Permissions(R.string.nav_permissions, Icons.Rounded.Shield),
    Profile(R.string.nav_profile, Icons.Rounded.Person),
}

/**
 * Root of the in-app UI: the current tab's content between two scrims, and a floating expressive
 * navigation bar. Content padding is computed once here so every tab clears both the top scrim and
 * the floating nav bar without each having to know about them.
 */
@Composable
fun MainScreen(viewModel: AppViewModel = viewModel()) {
    var selectedIndex by rememberSaveable { mutableIntStateOf(0) }
    var settingsRoute by rememberSaveable { mutableStateOf(SettingsRoute.List) }
    var profileRoute by rememberSaveable { mutableStateOf(ProfileRoute.List) }
    var selectedTileName by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedTile = selectedTileName?.let { name -> DynamicTile.entries.firstOrNull { it.name == name } }
    var selectedEventName by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedEvent = selectedEventName?.let { name -> SystemEventType.entries.firstOrNull { it.name == name } }
    val tabs = HomeTab.entries
    // Guard a saved index from an older build that had more tabs than this one.
    val current = tabs[selectedIndex.coerceIn(0, tabs.lastIndex)]
    val appearance by viewModel.appearance.collectAsStateWithLifecycle()
    val haptics = LocalHapticFeedback.current
    val context = LocalContext.current

    // On a detail screen the bottom bar becomes a back pill instead of the tab bar.
    val inSubScreen = (current == HomeTab.Settings && settingsRoute != SettingsRoute.List) ||
        (current == HomeTab.Profile && profileRoute != ProfileRoute.List)

    val navigateBack: () -> Unit = {
        when (current) {
            HomeTab.Profile -> profileRoute = ProfileRoute.List
            else -> settingsRoute = settingsRoute.parent
        }
    }

    // Drives the predictive-back "peek" animation: 0f = at rest, 1f = fully committed.
    val backProgress = remember { Animatable(0f) }
    var backEdge by remember { mutableIntStateOf(BackEventCompat.EDGE_LEFT) }

    // Read string resources during composition to use them in the export/import Toast callbacks.
    val exportFailedMsg: String = stringResource(R.string.export_failed)
    val exportSavedMsg: String = stringResource(R.string.export_to_path)
    val importSuccessMsg: String = stringResource(R.string.import_success)
    val importInvalidMsg: String = stringResource(R.string.import_invalid)
    val importFailedMsg: String = stringResource(R.string.import_failed)

    /**
     * When settings are exported, display a Toast as feedback
     */
    fun onSettingsExported(success: Boolean, path: String?) {
        val toast = Toast.makeText(
            context,
            if (success) "$exportSavedMsg $path" else exportFailedMsg,
            Toast.LENGTH_SHORT
        )
        toast.show()
    }

    /** When settings are imported, report the outcome as a Toast. */
    fun onSettingsImported(result: JsonSettings.ImportResult) {
        val message = when (result) {
            JsonSettings.ImportResult.SUCCESS -> importSuccessMsg
            JsonSettings.ImportResult.NOT_A_SETTINGS_FILE -> importInvalidMsg
            JsonSettings.ImportResult.ERROR -> importFailedMsg
        }
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    // Opens the system file picker for a JSON document; the picked file is read and applied by the
    // ViewModel. Filtering to application/json keeps unrelated files out of the picker.
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> uri?.let { viewModel.importSettingsFromUI(it) { result -> onSettingsImported(result) } } }

    PredictiveBackHandler(enabled = inSubScreen) { progress ->
        try {
            progress.collect { event ->
                backEdge = event.swipeEdge
                backProgress.snapTo(event.progress)
            }
            // Gesture committed: navigate back, then reset the transform for the new screen.
            navigateBack()
            backProgress.snapTo(0f)
        } catch (_: CancellationException) {
            // Gesture cancelled: ease the peek back to rest.
            backProgress.animateTo(0f)
        }
    }

    // No tab has an app bar: each screen carries its own heading (the app identity or a section
    // title on the list, the screen title in the back pill), so a bar would only waste height at
    // the top. A scrim mirroring the bottom one stands in for it.
    Scaffold { _ ->
        val navBarBottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val statusBarTopInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        // The scrim is only a fade for *scrolled* content, so content at rest starts below it —
        // same relationship the bottom padding has with the bottom scrim.
        val topScrimHeight = statusBarTopInset + 40.dp
        val contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = topScrimHeight + 8.dp,
            // Clear the floating nav bar (≈64dp tall) plus its bottom margin and the system bar.
            bottom = 96.dp + navBarBottomInset,
        )

        Box(modifier = Modifier.fillMaxSize().background(color = MaterialTheme.colorScheme.surfaceContainer)) {
            // Peek animation: as the user drags back, the content shrinks, rounds its corners
            // and slides toward the swiped edge, revealing the surface beneath.
            val contentTransform = Modifier.graphicsLayer {
                val p = backProgress.value
                if (p > 0f) {
                    val scale = 1f - 0.08f * p
                    scaleX = scale
                    scaleY = scale
                    translationX = (if (backEdge == BackEventCompat.EDGE_LEFT) 1f else -1f) * 16.dp.toPx() * p
                    shape = RoundedCornerShape(32.dp.toPx() * p)
                    clip = true
                }
            }
            Box(modifier = Modifier.fillMaxSize().then(contentTransform)) {
                AnimatedContent(
                    targetState = current,
                    transitionSpec = {
                        pageTransition(appearance.pageTransitionStyle)
                    },
                    label = "homeTab",
                ) { tab ->
                    when (tab) {
                        HomeTab.Settings -> SettingsTab(
                            viewModel = viewModel,
                            contentPadding = contentPadding,
                            route = settingsRoute,
                            selectedTile = selectedTile,
                            selectedEvent = selectedEvent,
                            onOpenSizePosition = { settingsRoute = SettingsRoute.SizePosition },
                            onOpenDynamicTiles = { settingsRoute = SettingsRoute.DynamicTiles },
                            onOpenTile = { tile ->
                                selectedTileName = tile.name
                                settingsRoute = SettingsRoute.DynamicTileDetail
                            },
                            onOpenApps = { settingsRoute = SettingsRoute.Apps },
                            onOpenBehaviour = { settingsRoute = SettingsRoute.Behaviour },
                            onOpenGestures = { settingsRoute = SettingsRoute.Gestures },
                            onOpenShowsWhenEmpty = { settingsRoute = SettingsRoute.ShowsWhenEmpty },
                            onOpenAnimation = { settingsRoute = SettingsRoute.Animation },
                            onOpenAppearance = { settingsRoute = SettingsRoute.Appearance },
                            onOpenBackground = { settingsRoute = SettingsRoute.Background },
                            onOpenActionButtons = { settingsRoute = SettingsRoute.ActionButtons },
                            onOpenDismissWindow = { settingsRoute = SettingsRoute.DismissWindow },
                            onOpenShizuku = { settingsRoute = SettingsRoute.Shizuku },
                            onOpenPermissionDot = { settingsRoute = SettingsRoute.PermissionDot },
                            onOpenSystemEvents = { settingsRoute = SettingsRoute.SystemEvents },
                            onOpenEvent = { event ->
                                selectedEventName = event.name
                                settingsRoute = SettingsRoute.EventDetail
                            },
                        )

                        HomeTab.Permissions -> PermissionsTab(contentPadding)

                        HomeTab.Profile -> ProfileTab(
                            viewModel = viewModel,
                            contentPadding = contentPadding,
                            route = profileRoute,
                            onOpenPermissionDetails = { profileRoute = ProfileRoute.PermissionDetails },
                            onOpenTesting = { profileRoute = ProfileRoute.Testing },
                            onExportSettings = { viewModel.exportSettingsFromUI { s, p -> onSettingsExported(s, p) } },
                            onImportSettings = { importLauncher.launch(arrayOf("application/json")) },
                        )
                    }
                }
            }

            // Soft scrim so scrolled content fades out beneath the floating bottom bar.
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Transparent,
                            0.7f to MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.7f),
                            1f to MaterialTheme.colorScheme.surfaceContainer,
                        ),
                    ),
            )

            // Standing in for the app bar: content fades out under the status bar as it scrolls,
            // instead of colliding with it.
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(topScrimHeight)
                    .background(
                        Brush.verticalGradient(
                            0f to MaterialTheme.colorScheme.surfaceContainer,
                            0.3f to MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.7f),
                            1f to Color.Transparent,
                        ),
                    ),
            )

            val barModifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 16.dp)

            if (inSubScreen) {
                val title = when (current) {
                    HomeTab.Profile -> when (profileRoute) {
                        ProfileRoute.PermissionDetails -> stringResource(R.string.profile_permissions_title)
                        ProfileRoute.Testing -> stringResource(R.string.profile_testing_title)
                        else -> stringResource(R.string.profile_version)
                    }
                    else -> when (settingsRoute) {
                        SettingsRoute.SizePosition -> stringResource(R.string.appearance_title)
                        SettingsRoute.DynamicTiles -> stringResource(R.string.dynamic_tiles_title)
                        SettingsRoute.DynamicTileDetail ->
                            selectedTile?.let { stringResource(it.labelRes) } ?: stringResource(R.string.dynamic_tiles_title)
                        SettingsRoute.Apps -> stringResource(R.string.apps_title)
                        SettingsRoute.Behaviour -> stringResource(R.string.behaviour_title)
                        SettingsRoute.Gestures -> stringResource(R.string.gestures_title)
                        SettingsRoute.ShowsWhenEmpty -> stringResource(R.string.behaviour_empty_pill)
                        SettingsRoute.Animation -> stringResource(R.string.animation_title)
                        SettingsRoute.Appearance -> stringResource(R.string.appearance_section_title)
                        SettingsRoute.Background -> stringResource(R.string.appearance_background_color)
                        SettingsRoute.ActionButtons -> stringResource(R.string.action_buttons_title)
                        SettingsRoute.DismissWindow -> stringResource(R.string.appearance_window_dismiss_title)
                        SettingsRoute.Shizuku -> stringResource(R.string.shizuku_options_title)
                        SettingsRoute.PermissionDot -> stringResource(R.string.permission_dot_title)
                        SettingsRoute.SystemEvents -> stringResource(R.string.integrations_system_events_title)
                        SettingsRoute.EventDetail ->
                            selectedEvent?.let { stringResource(it.labelRes) }
                                ?: stringResource(R.string.integrations_system_events_title)
                        else -> stringResource(R.string.section_icons_title)
                    }
                }
                BackNavBar(
                    title = title,
                    onBack = navigateBack,
                    modifier = barModifier,
                )
            } else {
                ExpressiveNavBar(
                    items = tabs.map { NavBarItem(stringResource(it.labelRes), it.icon) },
                    selectedIndex = selectedIndex,
                    onSelect = { index ->
                        if (index != selectedIndex) {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        selectedIndex = index
                    },
                    modifier = barModifier,
                )
            }
        }
    }
}
