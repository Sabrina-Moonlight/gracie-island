package com.ekoehler.expressivecutout.ui.screen

import android.app.Activity
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ekoehler.expressivecutout.R
import com.ekoehler.expressivecutout.data.AppLanguage
import com.ekoehler.expressivecutout.data.AppLanguages
import com.ekoehler.expressivecutout.system.AppLocale
import com.ekoehler.expressivecutout.ui.AppViewModel
import com.ekoehler.expressivecutout.ui.pageTransition
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ekoehler.expressivecutout.ui.components.ExpressiveSegmentedRow
import com.ekoehler.expressivecutout.ui.components.groupedShape
import com.ekoehler.expressivecutout.ui.theme.AppTheme

/** The screens reachable from the Profile tab. Hoisted to MainScreen, like [SettingsRoute]. */
enum class ProfileRoute { List, PermissionDetails, Testing }

/**
 * "Profile" destination: the app-wide theme choice, the version and the app's utility screens.
 * The selected theme is persisted and applied at the root of the activity.
 */
@Composable
fun ProfileTab(
    viewModel: AppViewModel,
    contentPadding: PaddingValues,
    route: ProfileRoute,
    onOpenPermissionDetails: () -> Unit,
    onOpenTesting: () -> Unit,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
) {
    val appearance by viewModel.appearance.collectAsStateWithLifecycle()
    AnimatedContent(
        targetState = route,
        transitionSpec = {
            val dir = if (targetState != ProfileRoute.List) 1 else -1
            pageTransition(appearance.pageTransitionStyle, dir)
        },
        label = "profileRoute",
    ) { current ->
        when (current) {
            ProfileRoute.List -> ProfileList(
                viewModel = viewModel,
                contentPadding = contentPadding,
                onOpenPermissionDetails = onOpenPermissionDetails,
                onOpenTesting = onOpenTesting,
                onExportSettings = onExportSettings,
                onImportSettings = onImportSettings,
            )
            ProfileRoute.PermissionDetails -> PermissionDetailsScreen(contentPadding)
            ProfileRoute.Testing -> TestingScreen(contentPadding)
        }
    }
}

@Composable
private fun ProfileList(
    viewModel: AppViewModel,
    contentPadding: PaddingValues,
    onOpenPermissionDetails: () -> Unit,
    onOpenTesting: () -> Unit,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
) {
    val context = LocalContext.current
    val theme by viewModel.theme.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val languages = remember(context) { AppLanguages.supported(context) }
    val versionName = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: "—"
    }

    val haptics = LocalHapticFeedback.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(contentPadding),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        AppHeader()

        Spacer(Modifier.height(24.dp))

        VersionCard(versionName = versionName, shape = cardShape(first = true))

        ThemeCard(
            selected = theme,
            onSelect = viewModel::setTheme,
            shape = cardShape(),
        )

        LanguageCard(
            languages = languages,
            selectedTag = language,
            onSelect = { tag ->
                if (tag != language) {
                    viewModel.setLanguage(tag)
                    if (!AppLocale.appliedBySystem) (context as? Activity)?.recreate()
                }
            },
            shape = cardShape(),
        )

        TestingCard(shape = cardShape(), onClick = {
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onOpenTesting()
        })

        ExportSettingsCard(cardShape(), onExportSettings, onImportSettings)

        PermissionDetailsCard(shape = cardShape(last = true), onClick = {
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onOpenPermissionDetails()
        })
    }
}

/**
 * The corners of a card stacked in the profile list: tight (4.dp) where it meets a neighbour, round
 * (24.dp) on the outer edges of the group, so the stack reads as one list rather than a handful of cards.
 */
private fun cardShape(first: Boolean = false, last: Boolean = false) = RoundedCornerShape(
    topStart = if (first) 24.dp else 4.dp,
    topEnd = if (first) 24.dp else 4.dp,
    bottomStart = if (last) 24.dp else 4.dp,
    bottomEnd = if (last) 24.dp else 4.dp,
)

/**
 * The app's identity at the top of the tab: Gracie's photo, the app name and the tagline.
 */
@Composable
private fun AppHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(R.drawable.gracie_avatar),
            contentDescription = stringResource(R.string.app_icon_description),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(104.dp)
                .clip(CircleShape),
        )
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp),
        )
        Text(
            text = stringResource(R.string.app_tagline),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

/** The app-wide theme choice: a title over the segmented selector, in a card of its own. */
@Composable
private fun ThemeCard(selected: AppTheme, onSelect: (AppTheme) -> Unit, shape: Shape) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(R.string.profile_theme),
                style = MaterialTheme.typography.labelLarge,
            )
            ExpressiveSegmentedRow(
                options = AppTheme.entries.map { stringResource(it.labelRes) },
                selectedIndex = selected.ordinal,
                onSelect = { onSelect(AppTheme.entries[it]) },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/**
 * The language the app is shown in. Tapping the card opens [LanguageDialog] over the list; the
 * entries come from res/xml/locales_config.xml, one per shipped values-<tag> folder.
 */
@Composable
private fun LanguageCard(
    languages: List<AppLanguage>,
    selectedTag: String,
    onSelect: (String) -> Unit,
    shape: Shape,
) {
    val haptics = LocalHapticFeedback.current
    var showPicker by remember { mutableStateOf(false) }
    val selected = languages.firstOrNull { it.tag == selectedTag } ?: languages.first()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                showPicker = true
            },
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Language,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(26.dp),
            )
            Spacer(Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.profile_language),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = selected.displayName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (showPicker) {
        LanguageDialog(
            languages = languages,
            selectedTag = selected.tag,
            onSelect = { tag ->
                showPicker = false
                onSelect(tag)
            },
            onDismiss = { showPicker = false },
        )
    }
}

/**
 * The language picker itself: every shipped language as a row, each labelled in its own language so
 * the list still reads for someone who cannot read the language the app is in. Picking a row is the
 * whole interaction, so the dialog closes on the tap and only carries a way out.
 */
@Composable
private fun LanguageDialog(
    languages: List<AppLanguage>,
    selectedTag: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val haptics = LocalHapticFeedback.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.profile_language)) },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .selectableGroup(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                languages.forEachIndexed { index, language ->
                    LanguageRow(
                        language = language,
                        selected = language.tag == selectedTag,
                        shape = groupedShape(
                            isFirst = index == 0,
                            isLast = index == languages.lastIndex,
                        ),
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(language.tag)
                        },
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

/** One language in [LanguageDialog], filled with the secondary container while it is the active one. */
@Composable
private fun LanguageRow(
    language: AppLanguage,
    selected: Boolean,
    shape: Shape,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .selectable(
                selected = selected,
                enabled = !selected,
                role = Role.RadioButton,
                onClick = onClick,
            ),
        shape = shape,
        color = if (selected) {
            MaterialTheme.colorScheme.secondaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        },
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = language.displayName,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) {
                    MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                modifier = Modifier.weight(1f),
            )
            if (selected) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

/** The installed version, shown large in a card of its own. */
@Composable
private fun VersionCard(versionName: String, shape: Shape) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
        ) {
            Text(
                text = stringResource(R.string.profile_version),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = versionName,
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

/** A clickable card that opens the per-permission explanations in [PermissionDetailsScreen]. */
@Composable
private fun PermissionDetailsCard(shape: Shape, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Shield,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(26.dp),
            )
            Spacer(Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.profile_permissions_title),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = stringResource(R.string.profile_permissions_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** A clickable card that opens the on-demand island triggers in [TestingScreen]. */
@Composable
private fun TestingCard(shape: Shape, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.Science,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(26.dp),
            )
            Spacer(Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.profile_testing_title),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = stringResource(R.string.profile_testing_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Export and import settings in a card */
@Composable
private fun ExportSettingsCard(
    shape: Shape,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = stringResource(R.string.profile_export_title), style = MaterialTheme.typography.titleMedium)
            Text(
                text = stringResource(R.string.profile_export_description),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = onExportSettings
                ) {
                    Icon(imageVector = Icons.Rounded.Upload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = stringResource(R.string.profile_export_export))
                }

                Button(
                    modifier = Modifier.weight(1f),
                    onClick = onImportSettings
                ) {
                    Icon(imageVector = Icons.Rounded.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = stringResource(R.string.profile_export_import))
                }
            }
        }

    }
}
